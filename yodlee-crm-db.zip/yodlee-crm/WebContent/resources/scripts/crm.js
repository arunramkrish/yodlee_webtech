function loadCustomers() {
	makeRequest("secured/customers.htm");
}

var httpRequest;

function makeRequest(url) {
	httpRequest = new XMLHttpRequest();

	if (!httpRequest) {
		alert('Giving up :( Cannot create an XMLHTTP instance');
		return false;
	}
	httpRequest.onreadystatechange = showContents;
	httpRequest.open('GET', url);
	httpRequest.send();
}

function showContents() {
	if (httpRequest.readyState === XMLHttpRequest.DONE) {
		if (httpRequest.status === 200) {
			document.getElementById("content").innerHTML = httpRequest.responseText;
		} else {
			alert('There was a problem with the request.');
		}
	}
}

function postCustomer(formObj) {
	var name = formObj['name'].value;
	var address = formObj['address'].value;
	var email = formObj['emailAddress'].value;
	var contact = formObj['contactNumber'].value;
	
	var dataToPost = "name=" + name + "&address=" + address + "&emailAddress=" + email + "&contactNumber=" + contact;
	var contentType = 'application/x-www-form-urlencoded';
	
	postRequest("addCustomer.htm", dataToPost, contentType);
}

function postRequest(url, data, contentType) {
	httpRequest = new XMLHttpRequest();

	if (!httpRequest) {
		alert('Giving up :( Cannot create an XMLHTTP instance');
		return false;
	}
	httpRequest.onreadystatechange = showContents;
	httpRequest.open('POST', url);
	httpRequest.setRequestHeader('Content-Type', contentType);
	httpRequest.send(data);
}
