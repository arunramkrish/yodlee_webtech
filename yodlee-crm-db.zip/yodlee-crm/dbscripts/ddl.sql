create table customers (id bigint identity primary key, name varchar(100), phone varchar(15), address varchar(200), email varchar(50));

insert into customers (name, phone, address, email) values ('ICICI', '45356456', 'BLR', 'icici@icicibank.com');
insert into customers (name, phone, address, email) values ('CITI', '45356456', 'BLR', 'citi@citibank.com');
insert into customers (name, phone, address, email) values ('INDIAN BANK', '45356456', 'BLR', 'indian@indianbank.com');
insert into customers (name, phone, address, email) values ('IOB', '45356456', 'BLR', 'iob@iobbank.com');
insert into customers (name, phone, address, email) values ('SBI', '45356456', 'BLR', 'sbi@sbiank.com');

