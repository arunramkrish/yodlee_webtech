create table customers (id bigint auto_increment primary key, name varchar(100), phone varchar(15), address varchar(200), email varchar(50));
