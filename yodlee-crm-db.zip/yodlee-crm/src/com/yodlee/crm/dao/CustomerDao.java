package com.yodlee.crm.dao;

import com.yodlee.crm.entities.Customer;

public interface CustomerDao extends BaseDao<Customer>{

}
