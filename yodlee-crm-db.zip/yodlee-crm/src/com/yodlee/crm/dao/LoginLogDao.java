package com.yodlee.crm.dao;

import com.yodlee.crm.entities.LoginLog;

public interface LoginLogDao extends BaseDao<LoginLog>{

}
