package com.yodlee.crm.dao;

import java.util.List;

public interface BaseDao <T> {
	void create(T entity) throws DaoException;
	
	List<T> get() throws DaoException;
}
