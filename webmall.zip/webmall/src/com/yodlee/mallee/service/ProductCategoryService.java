package com.yodlee.mallee.service;

public class ProductCategoryService {

}
