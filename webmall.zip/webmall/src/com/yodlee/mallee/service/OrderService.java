package com.yodlee.mallee.service;

public class OrderService {

}
