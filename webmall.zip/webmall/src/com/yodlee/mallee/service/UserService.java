package com.yodlee.mallee.service;

import com.yodlee.mallee.dao.jdbc.UserDao;
import com.yodlee.mallee.entity.User;

public class UserService {
	private UserDao userDao = new UserDao();
	
	public User registerUser(User user) {
		return userDao.create(user);
	}
}
