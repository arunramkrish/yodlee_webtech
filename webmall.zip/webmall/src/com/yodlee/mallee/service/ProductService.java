package com.yodlee.mallee.service;

import java.util.ArrayList;
import java.util.List;

import com.yodlee.mallee.entity.Product;
import com.yodlee.mallee.entity.ProductCatetory;

public class ProductService {
	public List<Product> getProducts(List<ProductCatetory> categories) {
		List<Product> products = getProducts();
		
//		filterProducts(products, categories);
		
		return products;
	}

	private void filterProducts(List<Product> products,
			List<ProductCatetory> categories) {
		// TODO Auto-generated method stub
		
	}

	private List<Product> getProducts() {
		List<Product> products = new ArrayList<Product>();
		Product p1 = new Product(1L, "Prod1", 10.0F, new ProductCatetory(1, "Fruits"));
		Product p2 = new Product(2L, "Prod2", 20.0F, new ProductCatetory(1, "Fruits"));
		Product p3 = new Product(3L, "Prod3", 30.0F, new ProductCatetory(2, "Vegetables"));
		Product p4 = new Product(4L, "Prod4", 40.0F, new ProductCatetory(2, "Vegetables"));
		Product p5 = new Product(5L, "Prod5", 50.0F, new ProductCatetory(3, "Groceries"));
		Product p6 = new Product(6L, "Prod6", 60.0F, new ProductCatetory(3, "Groceries"));
		
		products.add(p1);
		products.add(p2);
		products.add(p3);
		products.add(p4);
		products.add(p5);
		products.add(p6);
		
		return products;
	}
	
}
