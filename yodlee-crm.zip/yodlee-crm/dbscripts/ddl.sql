create table customers (id bigint identity primary key, name varchar(100), phone varchar(15), address varchar(200), email varchar(50));

insert into customers (name, phone, address, email) values ('ICICI', '45356456', 'BLR', 'icici@icicibank.com');
insert into customers (name, phone, address, email) values ('CITI', '45356456', 'BLR', 'citi@citibank.com');
insert into customers (name, phone, address, email) values ('INDIAN BANK', '45356456', 'BLR', 'indian@indianbank.com');
insert into customers (name, phone, address, email) values ('IOB', '45356456', 'BLR', 'iob@iobbank.com');
insert into customers (name, phone, address, email) values ('SBI', '45356456', 'BLR', 'sbi@sbiank.com');


create table users (
  user_name         varchar(15) not null primary key,
  user_pass         varchar(50) not null
);

create table user_roles (
  user_name         varchar(15) not null,
  role_name         varchar(25) not null,
  primary key (user_name, role_name)
);

insert into users(user_name, user_pass) values ('user1', 'f0578f1e7174b1a41c4ea8c6e17f7a8a3b88c92a');
insert into users(user_name, user_pass) values ('user2', '8be52126a6fde450a7162a3651d589bb51e9579d');
insert into users(user_name, user_pass) values ('admin1', 'f0578f1e7174b1a41c4ea8c6e17f7a8a3b88c92a');
insert into users(user_name, user_pass) values ('admin2', '8be52126a6fde450a7162a3651d589bb51e9579d');

insert into user_roles (user_name, role_name) values ('user1', 'crmuser');
insert into user_roles (user_name, role_name) values ('user2', 'crmuser');
insert into user_roles (user_name, role_name) values ('admin1', 'crmuser');
insert into user_roles (user_name, role_name) values ('admin1', 'admin');
insert into user_roles (user_name, role_name) values ('admin2', 'crmuser');
insert into user_roles (user_name, role_name) values ('admin2', 'admin');
