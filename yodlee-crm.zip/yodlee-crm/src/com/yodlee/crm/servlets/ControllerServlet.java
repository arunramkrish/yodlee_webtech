package com.yodlee.crm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yodlee.crm.dao.CustomerDao;
import com.yodlee.crm.dao.DaoException;
import com.yodlee.crm.dao.jdbc.CustomerJdbcDao;
import com.yodlee.crm.entities.Customer;

/**
 * Servlet implementation class ControllerServlet
 */
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ControllerServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.setAttribute("userName", request.getUserPrincipal()
					.getName());

			String[] availableRoles = { "admin", "crmuser" };

			List<String> roles = new ArrayList<String>();
			for (String role : availableRoles) {
				if (request.isUserInRole(role)) {
					roles.add(role);
		
				}
			}
			session.setAttribute("userRoles", roles);
		}

		String url = request.getRequestURI();
		if (url.endsWith("/home.htm")) {
			request.getRequestDispatcher("../WEB-INF/views/home.jsp").forward(
					request, response);
		} else if (url.endsWith("/customers.htm")) {
			CustomerDao customerDao = new CustomerJdbcDao();
			List<Customer> customers;
			try {
				customers = customerDao.get();
			} catch (DaoException e) {
				throw new ServletException("Error fetching customers", e);
			}

			request.setAttribute("customers", customers);
			request.getRequestDispatcher("../WEB-INF/views/customers.jsp")
					.forward(request, response);
		} else if (url.endsWith("addCustomers.htm")) {
			request.getRequestDispatcher("../WEB-INF/views/customerForm.jsp")
					.forward(request, response);

		} else if (url.endsWith("logout.htm")) {
			if (session != null) {
				session.invalidate();
			}
			response.sendRedirect("index.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String uri = request.getRequestURI();
		if (uri.endsWith("login.htm")) {
			// TODO authenticate
			HttpSession session = request.getSession(true);

			session.setAttribute("userName", request.getParameter("userName"));

			// request.getRequestDispatcher("WEB-INF/views/home.jsp").forward(request,
			// response);
			response.sendRedirect("index.jsp");
		} else if (uri.endsWith("addCustomer.htm")) {
			// var dataToPost = "name=" + name + "&address=" + address +
			// "&emailAddress=" + email + "&contactNumber=" + contact;
			Customer newCustomer = new Customer();
			newCustomer.setName(request.getParameter("name"));
			newCustomer.setAddress(request.getParameter("address"));
			newCustomer.setContactNumber(request.getParameter("contactNumber"));
			newCustomer.setEmailAddress(request.getParameter("emailAddress"));

			CustomerDao dao = new CustomerJdbcDao();
			try {
				dao.create(newCustomer);
			} catch (DaoException e) {
				throw new ServletException("Error creating customer", e);
			}

			response.sendRedirect("secured/customers.htm");

		}

	}

}
