package com.yodlee.crm.entities;

import java.util.Date;

public class LoginLog {
	private Long logId;
	private String userName;
	private Date loginTime;
	private Date logoutTime;
	public LoginLog() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getLogId() {
		return logId;
	}
	public void setLogId(Long logId) {
		this.logId = logId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public Date getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(Date logoutTime) {
		this.logoutTime = logoutTime;
	}

}
