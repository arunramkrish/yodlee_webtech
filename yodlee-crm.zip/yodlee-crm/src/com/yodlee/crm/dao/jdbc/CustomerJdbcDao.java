package com.yodlee.crm.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yodlee.crm.dao.CustomerDao;
import com.yodlee.crm.dao.DaoException;
import com.yodlee.crm.entities.Customer;


public class CustomerJdbcDao implements CustomerDao {

	@Override
	public void create(Customer entity) throws DaoException {
		Connection connection = null;
		PreparedStatement stmt = null;
		try {
			connection = JndiDatabaseUtil.getConnection();
			
			String sql = "INSERT INTO CUSTOMERS (name,phone, address, email) values(?, ?, ?, ?)";
			
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, entity.getName());
			stmt.setString(2, entity.getContactNumber());
			stmt.setString(3, entity.getAddress());
			stmt.setString(4, entity.getEmailAddress());
			
			int rows = stmt.executeUpdate();
			
			System.out.println("inserted successfully" + rows);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DaoException(e.getMessage(), e);
		} finally {
			JndiDatabaseUtil.releaseResources(connection, stmt, null);
		}
	}

	@Override
	public List<Customer> get() throws DaoException {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = JndiDatabaseUtil.getConnection();
			
			String sql = "SELECT id, name,phone, address, email FROM CUSTOMERS";
			
			stmt = connection.prepareStatement(sql);
			
			rs = stmt.executeQuery();
			List<Customer> customers = new ArrayList<Customer>();
			while (rs.next()) {
				Customer c = new Customer();
				c.setId(rs.getLong(1));
				c.setName(rs.getString(2));
				c.setContactNumber(rs.getString(3));
				c.setAddress(rs.getString(4));
				c.setEmailAddress(rs.getString(5));
				
				customers.add(c);
			}
			
			System.out.println("fetched successfully");
			return customers;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DaoException(e.getMessage(), e);
		} finally {
			JndiDatabaseUtil.releaseResources(connection, stmt, rs);
		}
	}

}
