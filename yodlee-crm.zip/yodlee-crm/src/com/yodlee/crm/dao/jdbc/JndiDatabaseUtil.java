package com.yodlee.crm.dao.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class JndiDatabaseUtil {
	private static DataSource dataSource;

	static {
		try {
			// Obtain our environment naming context
			Context initCtx;
			initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			// Look up our data source
			dataSource = (DataSource) envCtx.lookup("jdbc/yodleecrm");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}

	public static void releaseResources(Connection conn, Statement stmt,
			ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (Exception e) {

		}

		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (Exception e) {

		}

		try {
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {

		}

	}
}
