package com.yodlee.crm.dao;

import com.yodlee.crm.entities.User;

public interface UserDao extends BaseDao<User>{

}
