package com.yodlee.webportal.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class AuthFilter
 */
public class AuthFilter implements Filter {

	/**
	 * Default constructor.
	 */
	public AuthFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		HttpServletRequest svltRequest = (HttpServletRequest) request;
		HttpServletResponse svltResponse = (HttpServletResponse) response;
		HttpSession session = svltRequest.getSession(false);

		System.out.println(svltRequest.getRequestURI());

		if (session == null) {
			// forward to login page
			boolean cookiesModified = false;
			if (svltRequest.getCookies() != null) {
				for (Cookie cookie : svltRequest.getCookies()) {
					if (cookie.getName().equals("lastRequestURI")) {
						cookie.setValue(svltRequest.getRequestURI());
						cookiesModified = true;
					}
				}
			}
			if (!cookiesModified) {
				Cookie cookie = new Cookie("lastRequestURI",
						svltRequest.getRequestURI());
				svltResponse.addCookie(cookie);
			}
			svltResponse.sendRedirect("login.html");
		} else {
			// pass the request along the filter chain
			chain.doFilter(request, response);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
