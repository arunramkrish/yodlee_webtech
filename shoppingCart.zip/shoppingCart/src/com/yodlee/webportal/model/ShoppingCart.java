package com.yodlee.webportal.model;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
	private List<LineItem> items = new ArrayList<LineItem>();

	public List<LineItem> getItems() {
		return items;
	}

	public void setItems(List<LineItem> items) {
		this.items = items;
	}

	public void addToCart(LineItem lineItem) {
		items.add(lineItem);
	}
	
	@Override
	public String toString() {
		return "ShoppingCart [items=" + items + "]";
	}
	
}
