package com.yodleebank.dao;

import java.util.List;

import com.yodleebank.entity.Account;

public interface AccountDao {
	void create(Account account);

	Account get(String id);

	List<Account> getUserAccounts(String userId);
}
