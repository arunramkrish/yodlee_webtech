package com.yodleebank.dao;

import com.yodleebank.entity.User;

public interface UserDao {
	User get(String userId);
}
