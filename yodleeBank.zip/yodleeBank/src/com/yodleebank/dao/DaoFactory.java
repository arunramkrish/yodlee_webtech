package com.yodleebank.dao;

import com.yodleebank.dao.jdbc.AccountJdbcDao;
import com.yodleebank.dao.jdbc.BankJdbcDao;
import com.yodleebank.dao.jdbc.UserJdbcDao;

public class DaoFactory {
	private static AccountDao accountDao = new AccountJdbcDao();
	private static BankDao bankDao = new BankJdbcDao();
	private static UserDao userDao = new UserJdbcDao();

	public static AccountDao getAccountDao() {
		return accountDao;
	}

	public static BankDao getBankDao() {
		return bankDao;
	}

	public static UserDao getUserDao() {
		return userDao;
	}
}
