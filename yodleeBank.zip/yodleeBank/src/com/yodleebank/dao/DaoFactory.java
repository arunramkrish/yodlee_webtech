package com.yodleebank.dao;

public class DaoFactory {
	private static AccountDao accountDao;
	private static BankDao bankDao;
	private static UserDao userDao;

	public static AccountDao getAccountDao() {
		return accountDao;
	}

	public static BankDao getBankDao() {
		return bankDao;
	}

	public static UserDao getUserDao() {
		return userDao;
	}
}
