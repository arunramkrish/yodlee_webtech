package com.yodleebank.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.yodleebank.dao.UserDao;
import com.yodleebank.entity.User;

public class UserJdbcDao extends BaseJdbcDao implements UserDao {

	@Override
	public User get(String userId) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection
					.prepareStatement("select * from users where login_id = ? ");
			stmt.setString(1, userId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				String name = rs.getString("name");
				String loginId = rs.getString("login_id");
				String password = rs.getString("password");
				String phoneNumber = rs.getString("phone_number");
				Date dob = new Date(rs.getDate("dob").getTime());

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

}
