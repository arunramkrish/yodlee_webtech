package com.yodleebank.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yodleebank.dao.AccountDao;
import com.yodleebank.entity.Account;
import com.yodleebank.entity.Bank;

public class AccountJdbcDao extends BaseJdbcDao implements AccountDao {

	@Override
	public void create(Account account) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection
					.prepareStatement("insert into accounts (id, user_id, customer_id, account_number, bank_id, balance) values (?, ?, ?, ?, ?, ?)");
			rs = stmt.executeQuery();
			while (rs.next()) {

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}
	}

	@Override
	public Account get(Long id) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection
					.prepareStatement("select * from accounts where user_id = ? ");
			stmt.setLong(1, id);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Account account = new Account();
				account.setAccountNumber(rs.getString("account_number"));
				account.setBalance(rs.getDouble("balance"));
				
				Bank bank = new Bank();
				bank.setId(rs.getLong("id"));
				account.setBank(bank);
				account.setCustomerId(rs.getString("customer_id"));
				account.setUserId(rs.getString("user_id"));
				
				return account;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

	@Override
	public List<Account> getUserAccounts(String userId) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection
					.prepareStatement("select * from accounts where user_id = ? ");
			stmt.setString(1, userId);
			rs = stmt.executeQuery();
			List<Account> accounts = new ArrayList<Account>();
			while (rs.next()) {
				Account account = new Account();
				account.setAccountNumber(rs.getString("account_number"));
				account.setBalance(rs.getDouble("balance"));
				
				Bank bank = new Bank();
				bank.setId(rs.getLong("id"));
				account.setBank(bank);
				account.setCustomerId(rs.getString("customer_id"));
				account.setUserId(rs.getString("user_id"));
				
				accounts.add(account);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

}
