package com.yodleebank.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.yodleebank.dao.AccountDao;
import com.yodleebank.entity.Account;

public class AccountJdbcDao extends BaseJdbcDao implements AccountDao {

	@Override
	public void create(Account account) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection
					.prepareStatement("select * from users where login_id = ? ");
			stmt.setString(1, userId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

	@Override
	public Account get(String id) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection
					.prepareStatement("select * from users where login_id = ? ");
			stmt.setString(1, userId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

	@Override
	public List<Account> getUserAccounts(String userId) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection
					.prepareStatement("select * from users where login_id = ? ");
			stmt.setString(1, userId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

}
