package com.yodleebank.dao.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class BaseJdbcDao {
	private static String userName;
	private static String password;
	private static String url;
	private static String driverName;

	static {
		Properties props = new Properties();
		try {
			props.load(new FileInputStream("e:/jdbc.properties"));

			userName = props.getProperty("userName");
			password = props.getProperty("password");
			url = props.getProperty("url");
			driverName = props.getProperty("driverName");
			Class.forName(driverName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, userName, password);
	}

	public void releaseResources(Connection connection, Statement stmt,
			ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (Exception e) {
		}

		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (Exception e) {

		}
		try {
			if (connection != null) {
				connection.close();
			}
		} catch (Exception e) {

		}
	}
}
