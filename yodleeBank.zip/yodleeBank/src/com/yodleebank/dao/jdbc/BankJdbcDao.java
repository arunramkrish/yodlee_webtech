package com.yodleebank.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yodleebank.dao.BankDao;
import com.yodleebank.entity.Bank;

public class BankJdbcDao extends BaseJdbcDao implements BankDao {

	@Override
	public List<Bank> get() {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection.prepareStatement("select * from banks");
			rs = stmt.executeQuery();
			List<Bank> banks = new ArrayList<Bank>();
			while (rs.next()) {
				Bank bank = new Bank();
				
				bank.setId(rs.getLong("id"));
				bank.setBankName(rs.getString("name"));
				bank.setAddress(rs.getString("address"));
				bank.setIfsc(rs.getString("ifsc"));
				
				banks.add(bank);
			}
			return banks;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

	@Override
	public Bank get(Long id) {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection.prepareStatement("select * from banks where id = ?");
			stmt.setLong(1, id);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Bank bank = new Bank();
				
				bank.setId(rs.getLong("id"));
				bank.setBankName(rs.getString("name"));
				bank.setAddress(rs.getString("address"));
				bank.setIfsc(rs.getString("ifsc"));
				
				return bank;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

}
