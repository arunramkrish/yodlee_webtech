package com.yodleebank.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.yodleebank.dao.BankDao;
import com.yodleebank.entity.Bank;

public class BankJdbcDao extends BaseJdbcDao implements BankDao {

	@Override
	public List<Bank> get() {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			connection = getConnection();
			stmt = connection.prepareStatement("select * from banks");
			rs = stmt.executeQuery();
			while (rs.next()) {

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			releaseResources(connection, stmt, rs);
		}

		return null;
	}

}
