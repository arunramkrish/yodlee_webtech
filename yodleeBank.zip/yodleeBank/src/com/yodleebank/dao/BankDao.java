package com.yodleebank.dao;

import java.util.List;

import com.yodleebank.entity.Bank;

public interface BankDao {
	List<Bank> get();
}
