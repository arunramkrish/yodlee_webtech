package com.yodleebank.service;

import com.yodleebank.service.impl.YodleeServiceFacadeImpl;

public class ServiceFactory {
	private static YodleeServiceFacade serviceFacade = new YodleeServiceFacadeImpl();

	public static YodleeServiceFacade getYodleeServiceFacade() {
		return serviceFacade;
	}
}
