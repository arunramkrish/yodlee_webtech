package com.yodleebank.service;

import java.util.List;

import com.yodleebank.entity.Account;
import com.yodleebank.entity.Bank;
import com.yodleebank.entity.User;

public interface YodleeServiceFacade {
	Boolean authenticateUser(String loginId, String password);
	
	User getUserDetails(String loginId);
	
	List<Account> getAccounts(String userId);
	
	List<Bank> getBanks();
	
	Account getAccountDetails(String accountId);
}
