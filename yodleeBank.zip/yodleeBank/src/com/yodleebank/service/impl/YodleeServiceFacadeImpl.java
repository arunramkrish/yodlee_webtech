package com.yodleebank.service.impl;

import java.util.List;

import com.yodleebank.dao.AccountDao;
import com.yodleebank.dao.BankDao;
import com.yodleebank.dao.DaoFactory;
import com.yodleebank.dao.UserDao;
import com.yodleebank.entity.Account;
import com.yodleebank.entity.Bank;
import com.yodleebank.entity.User;
import com.yodleebank.service.YodleeServiceFacade;

public class YodleeServiceFacadeImpl implements YodleeServiceFacade {
	private BankDao bankDao = DaoFactory.getBankDao();
	private UserDao userDao = DaoFactory.getUserDao();
	private AccountDao accountDao = DaoFactory.getAccountDao();

	@Override
	public Boolean authenticateUser(String loginId, String password) {
		User user = userDao.get(loginId);
		if (user == null) {
			return false;
		}

		return user.getPassword().equals(password);
	}

	@Override
	public User getUserDetails(String loginId) {
		return userDao.get(loginId);
	}

	@Override
	public List<Account> getAccounts(String userId) {
		List<Account> accounts = accountDao.getUserAccounts(userId);
		for (Account a : accounts) {
			Long bankId = a.getBank().getId();

			Bank bank = bankDao.get(bankId);
			a.setBank(bank);
		}
		return accounts;
	}

	@Override
	public List<Bank> getBanks() {
		return bankDao.get();
	}

	@Override
	public Account getAccountDetails(Long accountId) {
		Account account = accountDao.get(accountId);
		Long bankId = account.getBank().getId();

		Bank bank = bankDao.get(bankId);
		account.setBank(bank);
		return account;
	}

}
