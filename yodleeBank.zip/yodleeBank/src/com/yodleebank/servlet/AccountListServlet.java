package com.yodleebank.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yodleebank.entity.Account;
import com.yodleebank.entity.Bank;
import com.yodleebank.entity.User;
import com.yodleebank.service.ServiceFactory;
import com.yodleebank.service.YodleeServiceFacade;

/**
 * Servlet implementation class AccountListServlet
 */
@WebServlet("/accountList.action")
public class AccountListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YodleeServiceFacade service = ServiceFactory.getYodleeServiceFacade();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		List<Account> accounts = new ArrayList<Account>();
//		Account account1 = new Account();
//		account1.setAccountNumber("1001");
//		account1.setBalance(1000.0);
//		Bank b = new Bank();
//		b.setBankName("ICICI");
//		account1.setBank(b);
//		
//		accounts.add(account1);
//		
//		Account account2 = new Account();
//		account2.setAccountNumber("1001");
//		account2.setBalance(1000.0);
//		account2.setBank(b);
//		accounts.add(account2);
		HttpSession session = request.getSession(false);
		if (session == null) {
			request.getRequestDispatcher("WEB-INF/views/login.jsp").forward(request, response);
			return;
		}
		String userId = ((User)session.getAttribute("user")).getLoginId();
		
		List<Account> accounts = service.getAccounts(userId);
		request.setAttribute("accounts", accounts);
		
		request.getRequestDispatcher("WEB-INF/views/accountsList.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
