package com.yodleebank.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yodleebank.entity.User;
import com.yodleebank.service.ServiceFactory;
import com.yodleebank.service.YodleeServiceFacade;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login.action")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YodleeServiceFacade service = ServiceFactory
			.getYodleeServiceFacade();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");

		if (service.authenticateUser(userName, password)) {
			//get user profile
			User user = service.getUserDetails(userName);
			
			//store user profile in session
			HttpSession session = request.getSession(true);
			session.setAttribute("user", user);
			
			//navigate to home page
//			response.sendRedirect
			request.getRequestDispatcher("WEB-INF/views/home.jsp").forward(
					request, response);
		} else {
			//invalid login - show back login page
			request.setAttribute("errorMessage", "Invalid user credentials");
			request.getRequestDispatcher("WEB-INF/views/login.jsp").forward(
					request, response);
			
		}
	}

}
