package com.yodleebank.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yodleebank.entity.Account;
import com.yodleebank.service.ServiceFactory;
import com.yodleebank.service.YodleeServiceFacade;

/**
 * Servlet implementation class AccountServlet
 */
@WebServlet("/account.action")
public class AccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YodleeServiceFacade service = ServiceFactory.getYodleeServiceFacade();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AccountServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if (idStr == null) {
			request.getRequestDispatcher("WEB-INF/views/accountForm.jsp").forward(
					request, response);
		} else {
			Long id = Long.parseLong(idStr);
			Account account = service.getAccountDetails(id);
			request.setAttribute("account", account);
			request.getRequestDispatcher("WEB-INF/views/accountForm.jsp").forward(
					request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
