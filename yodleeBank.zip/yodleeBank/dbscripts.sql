create table users (login_id varchar(25) primary key, name varchar(100) not null, password varchar(100), phone_number varchar(12), dob date); 

insert into users (login_id, name, password, phone_number) values ('arun', 'Arun Krish',  '9449804064');

insert into users (login_id, name, password, phone_number) values ('ram', 'Ram Krish',  '9449804063');

create table banks (id integer primary key, name varchar(50) not null, address varchar(100), ifsc varchar(20));

insert into banks (id, name, address, ifsc) values (1, 'ICICI Bank Koramangala', 'Koramangala Bangalore', 'ICICI000004');

insert into banks (id, name, address, ifsc) values (2, 'Indian Bank Koramangala', 'Koramangala Bangalore', 'IB00000004');

insert into banks (id, name, address, ifsc) values (3, 'Indian Overseas Bank Koramangala', 'Koramangala Bangalore', 'IOB000004');

private Long id;
	private String userId;
	private String customerId;
	private String accountNumber;
	private Bank bank;
	private Double balance;

create table accounts (id integer primary key, user_id varchar(25), customer_id varchar(50), account_number varchar(50), bank_id integer, balance double, foreign key(user_id) references users (login_id));

insert into accounts (id, user_id, customer_id, account_number, bank_id, balance) values (1, 'arun', 'CRF000001', '0470000001', 1, 100000);

insert into accounts (id, user_id, customer_id, account_number, bank_id, balance) values (2, 'arun', 'IBCR000001', '4410000001', 2, 100000);

insert into accounts (id, user_id, customer_id, account_number, bank_id, balance) values (3, 'arun', 'IOBC000001', '9970000001', 3, 100000);

insert into accounts (id, user_id, customer_id, account_number, bank_id, balance) values (4, 'ram', 'CRF000002', '0470000002', 1, 100000);

insert into accounts (id, user_id, customer_id, account_number, bank_id, balance) values (5, 'ram', 'IBCR000002', '4410000002', 2, 100000);

insert into accounts (id, user_id, customer_id, account_number, bank_id, balance) values (6, 'ram', 'IOBC000002', '9970000002', 3, 100000);


