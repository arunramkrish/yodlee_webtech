var xhr = new XMLHttpRequest();
function loadAccounts() {
	xhr.onload = handleResponse;
	xhr.open("get", "accountList.action", true);
	xhr.send();
}
function handleResponse() {
	if (xhr.readyState == 4) {
		if (xhr.status == 200) {
			document.getElementById("content").innerHTML = xhr.responseText;
		}
	}
}
function loadAccount(id) {
	xhr.onload = handleResponse;
	xhr.open("get", "account.action?id="+id, true);
	xhr.send();
}
function createAccount() {
	xhr.onload = handleResponse;
	xhr.open("get", "account.action", true);
	xhr.send();
}
