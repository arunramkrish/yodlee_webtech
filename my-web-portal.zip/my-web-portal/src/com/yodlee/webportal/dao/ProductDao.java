package com.yodlee.webportal.dao;

import java.util.HashMap;
import java.util.Map;

import com.yodlee.webportal.model.Product;

public class ProductDao {
	private static Map<Long, Product> productsInMemory = new HashMap<Long, Product>();
	
	static {
		productsInMemory.put(1L, new Product(1L, "Sona Masoori", 1000F, 55F, "ITC", "Raw Sona Masoori rice"));
		productsInMemory.put(2L, new Product(2L, "Rajma", 1000F, 55F, "Ashirwad", "Rajma"));
		productsInMemory.put(3L, new Product(3L, "Channa", 1000F, 55F, "ITC", "Channa Dhal"));
		productsInMemory.put(4L, new Product(4L, "Badam", 100F, 755F, "ITC", "Plain Badam"));
		productsInMemory.put(5L, new Product(5L, "Cashew", 100F, 655F, "ITC", "Plain Cashew"));
		productsInMemory.put(6L, new Product(6L, "Walnut", 100F, 855F, "ITC", "Walnut"));
		productsInMemory.put(7L, new Product(7L, "Dates", 1000F, 455F, "ITC", "Dates"));
		productsInMemory.put(8L, new Product(8L, "Gram Dhal", 300F, 55F, "ITC", "Gram Dhal"));
		productsInMemory.put(9L, new Product(9L, "Hazlenut", 1000F, 55F, "ITC", "Hazlenut plain"));
		productsInMemory.put(10L, new Product(10L, "Pista", 800F, 55F, "ITC", "Pista plain"));
		
	}
	
	public ProductDao() {
		
	}
	
	public Map<Long,Product> getProducts() {
		return productsInMemory;
	}
	
	public Product getProduct(Long id) {
		return productsInMemory.get(id);
	}
}
