package com.yodlee.webportal.model;

public class Product {
	private Long id;
	private String name;
	private Float availableQuantity;
	private Float unitPrice;
	private String manufacturerDetails;
	private String productSummary;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Product(Long id, String name, Float availableQuantity,
			Float unitPrice, String manufacturerDetails, String productSummary) {
		super();
		this.id = id;
		this.name = name;
		this.availableQuantity = availableQuantity;
		this.unitPrice = unitPrice;
		this.manufacturerDetails = manufacturerDetails;
		this.productSummary = productSummary;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Float getAvailableQuantity() {
		return availableQuantity;
	}

	public void setAvailableQuantity(Float availableQuantity) {
		this.availableQuantity = availableQuantity;
	}

	public Float getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Float unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getManufacturerDetails() {
		return manufacturerDetails;
	}

	public void setManufacturerDetails(String manufacturerDetails) {
		this.manufacturerDetails = manufacturerDetails;
	}

	public String getProductSummary() {
		return productSummary;
	}

	public void setProductSummary(String productSummary) {
		this.productSummary = productSummary;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", availableQuantity="
				+ availableQuantity + ", unitPrice=" + unitPrice
				+ ", manufacturerDetails=" + manufacturerDetails
				+ ", productSummary=" + productSummary + "]";
	}

}
