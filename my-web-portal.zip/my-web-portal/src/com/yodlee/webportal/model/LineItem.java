package com.yodlee.webportal.model;

public class LineItem {
	private Product product;
	private Float quantity;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Float getQuantity() {
		return quantity;
	}

	public void setQuantity(Float quantity) {
		this.quantity = quantity;
	}

	public LineItem(Product product, Float quantity) {
		super();
		this.product = product;
		this.quantity = quantity;
	}

	public LineItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "LineItem [product=" + product + ", quantity=" + quantity + "]";
	}
}
