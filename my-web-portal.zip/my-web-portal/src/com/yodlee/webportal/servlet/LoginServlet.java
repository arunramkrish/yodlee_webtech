package com.yodlee.webportal.servlet;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static PrintStream loginLogWriter;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init");

		String logFilePath = config.getInitParameter("logFilePath");
		try {
			loginLogWriter = new PrintStream(new FileOutputStream(logFilePath,
					true), true);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// extract params in the request
		String userName = request.getParameter("userId");
		String password = request.getParameter("password");

		if ("".equals(password)) {
			response.getOutputStream().println("Login failed");
		} else {
			HttpSession session = request.getSession(true);
			session.setAttribute("user", userName);

			loginLogWriter.println(new Date() + "|" + request.getRemoteAddr()
					+ "|" + request.getRemoteHost() + "|"
					+ request.getHeaderNames() + "|" + userName);
			// response.getOutputStream().println("Welcome " + userName);

			String lastRequestUri = null;
			for (Cookie cookie : request.getCookies()) {
				if (cookie.getName().equals("lastRequestURI")) {
					System.out.println(cookie.getValue());
					lastRequestUri = cookie.getValue();
					break;
				}
			}
			if (lastRequestUri == null) {
				request.getRequestDispatcher("home.jsp").forward(request,
						response);
			} else {
				response.sendRedirect(lastRequestUri);
			}
		}
	}

	@Override
	public void destroy() {
		super.destroy();

		loginLogWriter.close();
	}

}
