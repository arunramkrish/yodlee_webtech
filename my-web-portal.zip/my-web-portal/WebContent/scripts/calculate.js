var xhr;
function calculate(formObj) {
	try {
		var op1 = formObj["operand1"].value;
		var op2 = formObj["operand2"].value;
		var opr = formObj["operation"].value;

		console.log(op1 + " " + opr + " " + op2);

		xhr = new XMLHttpRequest();
		xhr.onreadystatechange = loadResult;
		xhr.open("post", "calculate.calc", true);
		xhr.setRequestHeader('Content-Type',
				'application/x-www-form-urlencoded');
		xhr.send("operand1=" + op1 + "&operand2=" + op2 + "&operation=" + opr);
	} catch (e) {
		console.log(e);
	}
	return false;
}

function loadResult() {
	if (xhr.readyState == 4) {
		if (xhr.status == 200) {
			document.getElementById("result").innerHTML = xhr.responseText;
		}
	}
}