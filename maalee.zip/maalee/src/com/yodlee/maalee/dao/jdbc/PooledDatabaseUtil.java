package com.yodlee.maalee.dao.jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;

public class PooledDatabaseUtil {
	private static Properties properties = new Properties();
	//Change 1
	private static BasicDataSource dataSource = new BasicDataSource();
	
	static {
		try {
			properties.load(PooledDatabaseUtil.class.getClassLoader()
					.getResourceAsStream("db.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private static String driver;
	private static String url;
	private static String user;
	private static String password;
	//Change 2
	private static int initialSize;
	private static int maxActive;
	private static int minIdle;

	static {
		driver = properties.getProperty("driver");
		url = properties.getProperty("url");
		user = properties.getProperty("user");
		password = properties.getProperty("password");
		//Change 3
		initialSize = Integer.parseInt(properties.getProperty("initialSize"));
		maxActive = Integer.parseInt(properties.getProperty("maxActive"));
		minIdle = Integer.parseInt(properties.getProperty("minIdle"));
	}

	// load jdbc driver
	static {
		try {
			Class.forName(driver);
			//Change 4
			dataSource.setDriverClassName(driver);
			dataSource.setUrl(url);
			dataSource.setUsername(user);
			dataSource.setPassword(password);
			dataSource.setInitialSize(initialSize);
			dataSource.setMaxActive(maxActive);
			dataSource.setMinIdle(minIdle);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() throws SQLException {
		//Change 5
		return dataSource.getConnection();
	}

	public static void releaseResources(Connection con, Statement stmt,
			ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		System.out.println(driver + " " + url + " " + user + " " + password);
	}

}
